public class Dish {
    String name;
    String foodCode;
    float price;
    int stock;

    public Dish(String name, String foodCode, float price, int stock) {
        this.name = name;
        this.foodCode = foodCode;
        this.price = price;
        this.stock = stock;
    }
}