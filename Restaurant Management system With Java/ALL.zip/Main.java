public class Main {
    public static void main(String[] args) {
        RestaurantSystem system = new RestaurantSystem();
        system.run();
    }
}